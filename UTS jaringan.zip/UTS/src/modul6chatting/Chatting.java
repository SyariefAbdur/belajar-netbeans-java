/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package modul6chatting;

/**
 * @author kadek
 */
public class Chatting {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Server1 s = new Server1();
        s.setVisible(true);
        // TODO code application logic here
    }
}
